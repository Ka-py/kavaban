# File mình share thuộc dạng ngon ở thời điểm hiện tại. Treo mượt không lỗi nên hãy giữ nguyên credit giúp mình nhé. 🌸
# Lưu ý: Đây là bản vá lỗi đầu tiên nên chưa có phiên bản dành cho hosting ! Mình sẽ update dần.
## Nhớ hãy fork (remix) đúng nguồn (@khoi0603k) tránh lỗi ✔

### Liên hệ mình qua:
- Facebook🪐 : Lương Trường Khôi
- Telegram🎶 : TrKhoi_Media
```
                  .----.
      .---------. | == |
      |.-"""""-.| |----|
      ||       || | == |
      ||       || |----|
      |'-.....-'| |::::|
      `"")---(""` |___.|
     /:::::::::::\" _  "
    /:::=======:::\`\`\
    `"""""""""""""`  '-'
```
# Cách sử dụng file:
## Bước 1:
- Vào  ``shell`` nhập ``npm install``
- Chờ nó tải xong
## Bước 2:
- Thêm appstate vào ``appstate.json``
- Sửa ``config.json`` và nhớ thêm uid bạn vào ``NDH``
- Nếu là iphone thì truy câp ``https://lunarkrystal.github.io/login`` để lấy appstate
## Bước 3: 
- Ấn Run để chạy bot và tận hưởng

# Lưu ý khi sử dụng:
- Giữ nguyên credit, không sửa linh tinh tránh lỗi
- Thắc mắc gì liên hệ qua Facebook mình