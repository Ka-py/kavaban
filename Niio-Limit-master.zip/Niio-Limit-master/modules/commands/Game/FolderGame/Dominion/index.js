// đk tài khoản
// xây dựng nhà
// update nhà 
// update bộ máy
// update quân lính
// update phòng thủ
// đánh chiếm 
// vòng quay may mắn
// 